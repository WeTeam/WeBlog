Post Install Steps
==================
* Perform an incremental publish to all publishing targets
* Rebuild the WeBlog search index
    - control panel > database > rebuild the weblog search
 index

Create a Blog
=============
* Create a new blog using the Modules/WeBlog/Blog branch